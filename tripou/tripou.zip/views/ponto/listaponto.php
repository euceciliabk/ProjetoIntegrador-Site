<?php
	require_once "controle.php";
	$controlePonto = criaControlePonto();
	$pontos = $controlePonto->getPontos();
	
	echo "Lista de Pontos Turísticos Cadastrados";

	foreach($pontos as $ponto) {
		echo "<br><div>";
		echo $ponto['quem'] . "(". $ponto['nome'] . ")<br>";
		echo $ponto['texto'];
		require 'views/ponto/removepontoform.php';
		echo "</div>";
	}
?>