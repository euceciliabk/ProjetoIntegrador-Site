<?php


require_once "conexao.php";
require_once "ponto/modelo.php";

class PersistenciaPonto implements PersistePonto { //
	private $persistencia;
	
	function __construct() {
		$this->persistencia = getConexao();
	}
	
	
	private function getUsuarioId($login){ //igual
		$query = "SELECT idusuario FROM usuario WHERE login='$login' LIMIT 1";
		$result = $this->persistencia->query($query);
		$usuid = NULL;
		if ($result && $result->num_rows > 0) {
			$usuid = $result->fetch_array(MYSQLI_ASSOC)['idusuario'];
		}
		return $usuid;
	}

	function removePonto($ponto) { //remove ponto ***
		$usuid = $this->getUsuarioId($ponto['quem']);
		$quando = $ponto['quando'];
		$query = "DELETE FROM pontoturistico WHERE criador_idusuario='$usuid' AND 
		quando='$quando'";
		$this->persistencia->query($query);
	}
	
	function salvaPonto($ponto) { // salva ponto
		$usuid = $this->getUsuarioId($ponto['quem']); 
		$result = NULL;
		if ($usuid) {
			$quando = $ponto['quando'];
			$texto = $ponto['texto']; 
			$nome = $ponto['nome'];
			$avaliacao = $ponto['avaliacao'];
			$local = $ponto['local'];
			$quanto = $ponto['quanto'];
			$tempo_seg = $ponto['tempo'] * 60; //converte tempo do formulário que está em minutos para segundos
			$tempo = gmdate("H:i:s", $tempo_seg); //converte tempo em segundos para notação HH:MM:SS
			$latitude = $ponto['latitude'];
			$longitude = $ponto['longitude'];
			$foto = $_FILES["foto"]["tmp_name"]; //MOD

			if ( $arquivo != "none" ) { //MOD
				$fp = fopen($foto, "rb");
				$conteudo = fread($fp, $tamanho);
				$conteudo = addslashes($conteudo);
				fclose($fp); 
			}
			

			$query = "INSERT INTO pontoturistico (criador_idusuario, quando, descricao, nome, avaliacao, localizacao, preco, tempo, latitude, longitude, foto) 
			VALUES ('$usuid', '$quando','$texto','$nome', '$avaliacao', '$local', '$quanto','$tempo', '$latitude', '$longitude', '$conteudo')"; // atributos da tabela ponto turistico
			$result = $this->persistencia->query($query);
			
		}
			return $result;
	}
	
	private function getLoginUsuario($usuid) { //igual
		$query = "SELECT login FROM usuario WHERE idusuario='$usuid' LIMIT 1";
		$result = $this->persistencia->query($query);
		$login = NULL;
		if ($result && $result->num_rows > 0) {
			$login = $result->fetch_array(MYSQLI_ASSOC)['login'];
		}
		return $login;
	}
	
	function carregaPontos(){ //carrega pontos
		$query = "SELECT * FROM pontoturistico";
		$result = $this->persistencia->query($query);
		$pontos = array();
		if ($result && $result->num_rows > 0){ //importante
			while ($row = $result->fetch_array(MYSQLI_ASSOC)){
				$login = $this->getLoginUsuario($row['criador_idusuario']);
				$ponto = criaPonto( $login, $row['idpontoTuristico'], $row['quando'], $row['descricao'], $row['nome'], $row['avaliacao'], $row['localizacao'], $row['preco'], $row['tempo'], $row['latitude'], $row['longitude']);
				//$quem, $quando, $texto, $nome, $avaliacao, $local, $quanto, $tempo
				array_push($pontos, $ponto);
			}
		}
		return $pontos;
	}
	
}

?>