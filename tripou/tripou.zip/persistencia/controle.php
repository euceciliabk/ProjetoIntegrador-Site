<?php
require_once "mysql/controle.php";
?>