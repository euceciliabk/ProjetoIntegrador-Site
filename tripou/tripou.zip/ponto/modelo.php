<?php

interface PersistePonto {
	function carregaPontos();
	function salvaPonto($ponto);
	function removePonto($ponto);
}

function criaPonto($quem, $idponto, $quando, $texto, $nome, $avaliacao, $local, $quanto, $tempo, $latitude, $longitude) { //*** 
	$ponto = array();
	$ponto ['quem'] = $quem;
	$ponto ['quando'] = $quando;
	$ponto ['texto'] = $texto;
	$ponto ['nome'] = $nome;
	$ponto ['avaliacao'] = $avaliacao;
	$ponto ['local'] = $local;
	$ponto ['quanto'] = $quanto;
	$ponto ['tempo'] = $tempo;
	$ponto ['latitude'] = $latitude;
	$ponto ['longitude'] = $longitude;
	$ponto ['idponto'] = $idponto;
	return $ponto;
}

?>